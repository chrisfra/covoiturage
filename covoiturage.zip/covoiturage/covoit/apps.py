from django.apps import AppConfig


class CovoitConfig(AppConfig):
    name = 'covoit'
